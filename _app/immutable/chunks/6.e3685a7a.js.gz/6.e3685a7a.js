import{default as t}from"../entry/(blog-article)-customization-page.md.4a60ec58.js";export{t as component};
