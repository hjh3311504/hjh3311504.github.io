import{default as t}from"../entry/_page.svelte.96c50829.js";export{t as component};
