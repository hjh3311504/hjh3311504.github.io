import{default as t}from"../entry/(blog-article)-layout.svelte.af90de96.js";export{t as component};
