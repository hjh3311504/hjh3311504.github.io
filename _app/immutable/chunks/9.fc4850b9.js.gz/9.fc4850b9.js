import{default as t}from"../entry/(waves)-blog-page.svelte.83f11aef.js";export{t as component};
