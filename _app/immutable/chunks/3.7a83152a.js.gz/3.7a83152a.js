import{default as t}from"../entry/(waves)-layout.svelte.0f572d3f.js";export{t as component};
