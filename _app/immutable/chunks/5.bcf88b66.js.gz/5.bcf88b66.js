import{default as t}from"../entry/(blog-article)-blog-posts-page.md.5f76d9c3.js";export{t as component};
