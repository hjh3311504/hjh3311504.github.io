import{default as t}from"../entry/_error.svelte.7e9e15cb.js";export{t as component};
