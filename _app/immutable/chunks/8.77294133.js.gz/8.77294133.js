import{default as t}from"../entry/(waves)-404-page.svelte.b1923387.js";export{t as component};
