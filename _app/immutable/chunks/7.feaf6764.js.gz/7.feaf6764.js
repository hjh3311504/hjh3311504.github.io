import{default as t}from"../entry/(blog-article)-project-structure-page.md.1ea804c7.js";export{t as component};
